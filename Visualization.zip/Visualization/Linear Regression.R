library(tidyverse)
library(dplyr)
library(scales)
library(fmsb)
library(ggrepel)

#=====================  liner regression ==================================

Towns = read_csv("Cleaning/Cleaned Data/clean_Town_population.csv")%>%
  select(shortPostcode, Town, District, County)

prices = read_csv("Cleaning/  Cleaned Data/cleanhouse_2019-2022.csv")

speeds = read_csv("Cleaning/Cleaned Data/clean_Broadband_Speed.csv") %>% 
  na.omit()  

crime=read_csv("Cleaning/ Cleaned Data/cleanedCrime.csv")

schools=read_csv("Cleaning/Cleaned Data/cleanedSchoolData.csv") %>% 
  na.omit()

#------------------------------House prices vs Download Speed----------------------------------------
options(scipen=999)
HousePrices = prices %>%
  filter(Year=="2021" | Year=="2022") %>%
  left_join(Towns,by="shortPostcode") %>%  
  group_by(Town,County) %>%
  summarise(Price=mean(Price))
BroardbandSpeeds = speeds %>%
  left_join(Towns,by="shortPostcode") %>%
  group_by(Town,County) %>%
  summarise(AverageDownload=mean(Avgdownload))
lm_res = HousePrices %>% left_join(BroardbandSpeeds,by="Town")
model = lm(data= lm_res, Price~AverageDownload)
summary(model)
color= c("OXFORDSHIRE" = "purple", "YORKSHIRE" = "yellow")
ggplot(lm_res,aes(x=AverageDownload,y=Price)) +
  geom_point(data = filter(lm_res,County.x=="YORKSHIRE"),aes(color="YORKSHIRE"))+
  geom_point(data = filter(lm_res,County.x=="OXFORDSHIRE"), aes(color="OXFORDSHIRE")) +
  geom_smooth(method=lm,se=FALSE,color="black")+
  labs(x="Download Speed (Mbit/s)",y="Price",title=" Download Speed vs House Prices ",color="County")


#----------------------------------House price and drug offence--------------------------------------------------
HousePrices <- prices %>%
  filter(Year == "2021" | Year == "2022") %>%
  left_join(Towns, by = "shortPostcode") %>%  
  group_by(Town, County) %>%
  summarise(Price = mean(Price))

# Calculate mean attainment scores by town and county
attainment <- schools %>%
  left_join(Towns, by = "shortPostcode") %>%  
  group_by(Town, County) %>%
  summarise(meanAttainment = mean(Attainment8Score))

# Merge data for house prices and attainment by town
lm_res2 <- HousePrices %>%
  left_join(attainment, by = "Town") %>% 
  na.omit()

# Check if lm_res2 has non-zero cases before performing linear regression
if (nrow(lm_res2) > 0) {
  model2 <- lm(data = lm_res2, Price ~ meanAttainment)
  summary(model2)
  
  # Define color palette
  color <- c("OXFORDSHIRE" = "purple", "YORKSHIRE" = "green")
  
  # Create scatter plot if lm_res2 has non-zero cases
  ggplot(lm_res2, aes(x = meanAttainment, y = Price)) +
    geom_point(data = filter(lm_res2, County.x == "YORKSHIRE"), aes(color = "YORKSHIRE")) +
    geom_point(data = filter(lm_res2, County.x == "OXFORDSHIRE"), aes(color = "OXFORDSHIRE")) +
    geom_smooth(method = lm, se = FALSE, color = "green") +
    labs(x = "attainment", y = "Price", title = "Average Attainment vs House Prices", color = "County")
} else {
  cat("No valid data for linear regression and plot.")
}










#=================   average attainment  vs house prices ==================
attainment= schools %>%
  left_join(Towns,by="shortPostcode") %>%  
  group_by(Town,County) %>%
  summarise(meanAttainment=mean(Attainment8Score))
attainment
HousePrices = prices %>%
  left_join(Towns,by="shortPostcode") %>%  
  group_by(Town,County) %>%
  summarise(Price=mean(Price))

lm_res2 = HousePrices %>% left_join(attainment ,by="Town") %>% 
  na.omit()
lm_res2
model1 = lm(data= lm_res2, Price~meanAttainment)
summary(model1)

color= c("OXFORDSHIRE" = "purple", "YORKSHIRE" = "Green")

ggplot(lm_res2,aes(x=meanAttainment,y=Price)) +
  geom_point(data = filter(lm_res2,County.x=="YORKSHIRE"),aes(color="YORKSHIRE"))+
  geom_point(data = filter(lm_res2,County.x=="OXFORDSHIRE"), aes(color="OXFORDSHIRE")) +
  geom_smooth(method=lm,se=FALSE,color="green")+
  labs(x="attainment",y="Price",title="average attainment  vs house prices",color="County")


#===========   average attenment score vs drug offence per 10000 people ========
Towns = read_csv("Cleaned Data/clean_Town_population.csv")
attainment= schools %>%
  left_join(Towns,by="shortPostcode") %>%  
  group_by(Town,County) %>%
  summarise(meanAttainment=mean(Attainment8Score))

Drugs = crime %>%
  left_join(Towns,by="shortPostcode") %>%
  group_by(Town,County) %>%
  filter(CrimeType=="Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2019+Population2020+Population2021+Population2022)) * 10000) %>% 
  as_tibble() %>% 
  na.omit()

lm_res3 = Drugs %>% left_join(attainment ,by="Town") %>% 
  na.omit()
lm_res3

model3 = lm(data= lm_res3, DrugOffenceRate~meanAttainment)
summary(model3)

color= c("OXFORDSHIRE" = "blue", "YORKSHIRE" = "red")
ggplot(lm_res3,aes(x=meanAttainment,y=DrugOffenceRate)) +
  geom_point(data = filter(lm_res3,County.x=="YORKSHIRE"),aes(color="YORKSHIRE"))+
  geom_point(data = filter(lm_res3,County.x=="OXFORDSHIRE"), aes(color="OXFORDSHIRE")) +
  geom_smooth(method=lm,se=FALSE,color="black")+
  labs(x="attainment",y="Drups per 10000",title="average attenment score vs drug offence per 10000 people ",color="County")

#========= average download speed vs average attainment score ======

# Calculate mean attainment score per town and county
attainment <- schools %>%
  left_join(Towns, by = "shortPostcode") %>%  
  group_by(Town, County) %>%
  summarise(meanAttainment = mean(Attainment8Score))

# Calculate average download speed per town and county
download_speeds <- speeds %>%
  left_join(Towns, by = "shortPostcode") %>% 
  group_by(Town, County) %>%
  summarise(meanDownloadSpeed = mean(Avgdownload)) %>%
  na.omit()

# Merge the data frames and remove rows with missing values
lm_res5 <- attainment %>%
  left_join(download_speeds, by = "Town") %>% 
  na.omit()

model <- lm(meanDownloadSpeed ~ meanAttainment, data = lm_res5)

summary(model)

# Create a scatter plot
color <- c("OXFORDSHIRE" = "blue", "YORKSHIRE" = "red")

ggplot(lm_res5, aes(x = meanAttainment, y = meanDownloadSpeed)) +
  geom_point(data = filter(lm_res5, County.x == "YORKSHIRE"), aes(color = "YORKSHIRE")) +
  geom_point(data = filter(lm_res5, County.x == "OXFORDSHIRE"), aes(color = "OXFORDSHIRE")) +
  geom_smooth(method = lm, se = FALSE, color = "black") +
  labs(x = "Average Attainment Score", y = "Average Download Speed", title = " Average Download Speed vs Average Attainment Score ", color = "County")