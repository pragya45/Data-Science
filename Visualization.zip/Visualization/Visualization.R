#install.packages("fmsb")
#install.packages("ggrepel")
library(tidyverse)
library(dplyr)
library(scales)
library(fmsb)
library(ggrepel)

setwd("D:\\DATASCIENCE")

euro <- dollar_format(prefix = "\u20ac", big.mark = ",")

#House Prices
Towns_Population = read_csv("Cleaning\\Cleaned Data\\Cleaned_Town_population.csv") %>% 
  select(-Year) 
HousePrices=read_csv("Cleaning\\Cleaned DataCleaned_House_Pricing_2019-2022.csv", show_col_types = FALSE)

HousePricesclean <- HousePrices %>% 
  select(-PostCode) %>% 
  left_join(Towns_Population, by ="shortPostcode")

HousePricesclean$County[HousePricesclean$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"

House_town = HousePricesclean %>% 
  #filter(County=="OXFORDSHIRE"|County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE") %>% 
  filter(County=="OXFORDSHIRE"|County=="YORKSHIRE") %>% 
  group_by(Town,District,County,Year) %>% 
  summarise(AveragePrice= mean(Price)) %>% 
  ungroup(Town,District,County,Year) %>%
  na.omit()
write.csv(House_town,"cleaning/Cleaned Data/Town_House.csv",row.names = FALSE)

# BOXPLOT Average house prices (2022)
House_town %>% 
  group_by(District) %>% 
  ggplot(aes(x = District, y = AveragePrice, fill=District)) +
  scale_y_continuous(limits=c(0,2000000), breaks = seq(0,2000000,200000), 
                     label = euro) +
  geom_boxplot() +
  coord_flip() +
  labs(title="2022 house prices by district")


#BARGRAPH houseprices by district (2019-2022)
HousePricesclean %>%
  group_by(District) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = District, y = AveragePrice)) +
  geom_bar(position = "stack",stat = "identity", fill = "LightGreen") +
  scale_y_continuous(limits=c(0,5000000),breaks = seq(0, 5000000, 30000),
                     label = euro) +
  geom_text(aes(label = euro(AveragePrice)),
            vjust = -0.25) +
  labs(title = "2019-2022 Average house prices by district") +
  coord_flip()


#LINEGRAPH Average house prices by year (2019-2022)
HousePricesclean %>%
  mutate(Year = as.numeric(Year)) %>%  # Convert Year to numeric if not already
  group_by(Year) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = Year, y = AveragePrice)) +
  geom_line(size = 1.5, color = "grey") +
  geom_text(aes(label = dollar_format()(AveragePrice)), vjust = -0.85) +
  scale_y_continuous(labels = dollar_format(prefix = "$"), breaks = seq(0, 300000, 5000)) +
  scale_x_continuous(breaks = seq(2019, 2022, 1), minor_breaks = NULL) +
  geom_point(size = 2, color = "dark Blue") +
  labs(title = "2019-2022 Average house prices by year",
       x = "Year",
       y = "Average Price")


#BROADBAND
Towns = read_csv("Cleaning\\Cleaned Data\\Cleaned_Town_population.csv")%>% 
  select(shortPostcode, Town, District, County)
BroadbandCleaned = read_csv("Cleaning\\Cleaned Data\\Cleaned_Broadband_Speed.csv", show_col_types = FALSE)

broadband=Towns %>% 
  left_join(BroadbandCleaned,by="shortPostcode")
View(broadband)

#Oxfordshire Broadband Speeds Visualization
ggplot(broadband,aes(y=Town)) +
  labs(x="Speeds (Mbits/s)",y="Town",title=" Oxfordshire Broadband Speeds")+
  geom_bar(data=filter(broadband,County=="OXFORDSHIRE"),aes(x=Avgdownload,fill="Average"),stat="Identity")+
  geom_bar(data=filter(broadband,County=="OXFORDSHIRE"),aes(x=Mindownload,fill="Minimum"),stat="Identity")+
  guides(fill=guide_legend("Download Speeds"))

#Yorkshire Broadband Speeds Visualization
ggplot(broadband,aes(y=Town)) +
  labs(x="Speeds (Mbits/s)",y="Town",title=" Yorkshire Broadband Speeds")+
  geom_bar(data=filter(broadband,County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE")
           ,aes(x=Avgdownload,fill="Average"),stat="Identity")+
  geom_bar(data=filter(broadband,County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE")
           ,aes(x=Mindownload,fill="Minimum"),stat="Identity")+
  guides(fill=guide_legend("Download Speeds"))

#Average Download Speed by District Visualization
broadband %>% 
  group_by(County) %>% 
  ggplot(aes(x = County, y = Avgdownload, fill=County)) +
  scale_y_continuous(breaks = seq(0,200,10)) +
  geom_boxplot() +
  labs(title = "Average download speed (Mbit/s) by district", x = "District",
       y = "Average Download Speed (Mbit/s)")+
  coord_flip()


#CRIME
Town = read_csv("Cleaning\\Cleaned Data\\Cleaned_Town_population.csv")%>% 
  select(-Year)
crime_Data = read_csv("Cleaning\\Cleaned Data\\cleanedCrime.csv")
View(Town)

crimeData = crime_Data %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit()

crimeData$County[crimeData$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"

view(crimeData)

# Create the boxplot
crimeData %>%
  filter(CrimeType == "Drugs") %>%
  ggplot(aes(x=District, y=CrimeCount, fill=CrimeType)) +
  geom_boxplot() +
  labs(title=" 2021-2022 Drugs count by District")+
  coord_flip()


#========Drug Offence Rate per 10000 in 2021-2022 =========

filtered_data <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

ggplot(data = filtered_data, aes(x = County, y = CrimeCount, fill = CrimeType)) +
  geom_boxplot() +
  labs(title = "Drug Offence Rate per 10000 in 2021-2022") +
  coord_flip()

# Piechart for 2021 Robbery 
RobberyData <- crimeData %>% 
  filter(CrimeType=="Robbery", Year == 2022) %>%
  group_by(District) %>%
  mutate(sumCount = sum(CrimeCount)) %>% 
  ungroup() %>%
  mutate(perc =sumCount / sum(CrimeCount)) %>% 
  arrange(perc) %>%
  mutate(labels = scales::percent(perc)) %>% 
  distinct(District, sumCount, perc, labels) %>% 
  select(District, sumCount, perc, labels)

RobberyData %>% 
  ggplot(aes(x = "", y = perc, fill = District)) +
  geom_col(color = "white") +
  geom_label(aes(label = labels),color="black",
             position = position_stack(vjust = 0.5),
             show.legend = FALSE) +
  coord_polar(theta = "y") +
  theme_void()+
  labs(title="2022 Robbery by District")


#LINEGRAPH of drug offence rate per 10000 people from 2021 -2022 of both city
# Filter and calculate drug offense rate per town and county for years 2022 and 2022

Drugs_2021_2022 <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

# Create a line chart
ggplot(Drugs_2021_2022, aes(x = Year, y = DrugOffenceRate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")


#New Code

Town = read_csv("Data Cleaning\\CleanedData\\PopCleanedData.csv")%>% 
  select(-Year)
crime_Data = read_csv("Data Cleaning\\CleanedData\\CrimeCleanedData.csv")
View(Town)

crimeData = crime_Data %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit()

crimeData$County[crimeData$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"
view(crimeData)

# Create the boxplot 2021-2022
crimeData %>%
  filter(CrimeType == "Drugs") %>%
  ggplot(aes(x=District, y=CrimeCount, fill=CrimeType)) +
  geom_boxplot() +
  labs(title=" 2021-2022 Drugs Rate by District")+
  coord_flip()




#========Drug Offence Rate per 10000 in 2021-2022 =========
filtered_data <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

ggplot(data = filtered_data, aes(x = County, y = CrimeCount, fill = CrimeType)) +
  geom_boxplot() +
  labs(title = "Drug Offence Rate per 10000 in 2021-2022") +
  coord_flip()






#radarchart
subset_data <- Vehicle_Crime_Rate2021_2022_Cleaned %>%
  filter(Crime.type == "Vehicle crime")
values <- subset_data %>%
  select(Crime.type, Falls.within, Location)  # Replace with the actual columns
radarchart(values, axistype = 1, 
           # Add other customization options as needed
           pfcol = "blue", plwd = 2, cglcol = "gray", cglty = 1, axislabcol = "black")





#piechart
RobberyData <- crimeData %>% 
  filter(CrimeType=="Robbery", Year == 2022) %>%
  group_by(District) %>%
  mutate(sumCount = sum(CrimeCount)) %>% 
  ungroup() %>%
  mutate(perc =sumCount / sum(CrimeCount)) %>% 
  arrange(perc) %>%
  mutate(labels = scales::percent(perc)) %>% 
  distinct(District, sumCount, perc, labels) %>% 
  select(District, sumCount, perc, labels)


RobberyData %>% 
  ggplot(aes(x = "", y = perc, fill = District)) +
  geom_col(color = "white") +
  geom_label(aes(label = labels),color="black",
             position = position_stack(vjust = 0.5),
             show.legend = FALSE) +
  coord_polar(theta = "y") +
  theme_void()+
  labs(title="2022 Robbery by District")



# Filter and calculate drug offense rate per town and county for years 2022 and 2022

Drugs_2021_2022 <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

# Create a line chart
ggplot(Drugs_2021_2022, aes(x = Year, y = DrugOffenceRate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")



##################################################
schoolData = read_csv("cleaning/cleanedData/cleanedSchoolData.csv", show_col_types = FALSE)
OXFORDSHIRESchoolData = read_csv("cleaning/cleanedData/OXFORDSHIRESchoolData.csv")
YORKSHIRESchoolData = read_csv("cleaning/cleanedData/YORKSHIRESchoolData.csv")

schoolData = schoolData %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit() 


#- box plot= average attainment in 2022 both country district

schoolData %>%
  group_by(District) %>%
  summarise(AverageAttainment = mean(Attainment8Score)) %>%
  ggplot(aes(x = factor(District), y = AverageAttainment)) +
  geom_boxplot(color = "red", fill = "steelblue") +  
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  scale_x_discrete() +
  labs(title = "Average Attainment8Score by district")


merged_data <- OXFORDSHIRESchoolData %>%
  inner_join(Town, by ="shortPostcode") %>% 
  na.omit()
view(merged_data)
merged_data$Attainment8Score <- as.numeric(merged_data$Attainment8Score)
filtered_data <- merged_data %>%
  filter(Year %in% c(2021, 2022)) %>%
  group_by(District, Year) %>%
  summarise(AverageAttainment = mean(Attainment8Score))
filtered_data
ggplot(filtered_data, aes(x = Year, y = AverageAttainment, group = District)) +
  geom_line(size = 1, color = "red") +
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  geom_point(size = 2, color = "black") +
  labs(title = "Oxfordshire District Average Attainment Score from 2021 to 2022")



#line chart = Yorkshire  district average attainment score from 2020-2022

merged_data_york <- YORKSHIRESchoolData %>%
  inner_join(Town, by ="shortPostcode")
view(merged_data_york)
filtered_data_york <- merged_data_york %>%
  filter(Year == 2020 | Year == 2021 | Year == 2022) %>%
  group_by(District,Year) %>%
  summarise(AverageAttainment = mean(Attainment8Score)) 
filtered_data_york
ggplot(filtered_data_york, aes(x = Year, y = AverageAttainment, group = District)) +
  geom_line(size = 1, color = "red") +
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  geom_point(size = 2, color = "black") +
  labs(title = "Yorkshire District Average Attainment Score from 2020 to 2022")
