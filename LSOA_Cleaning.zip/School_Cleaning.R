library(tidyverse)
library(dplyr)
library(stringi)
library(scales)
library(data.table)

setwd("D:\\DATASCIENCE")

# Read the CSV file and assign the year
School_2021_2022 <- fread("Datasets\\Performancetables_034335\\2021-2022\\school2021.csv", fill = TRUE) %>%
  mutate(Year = 2021)

# Select relevant columns, remove missing values, and keep distinct records
School_2021_2022 <- School_2021_2022 %>%
  select(Year, PCODE, SCHNAME, ATT8SCR) %>%
  drop_na() %>%
  distinct()

# Read the CSV file and assign the year
School_2022_2023 <- fread("Datasets\\Performancetables_034335\\2021-2022\\school2021.csv", fill = TRUE) %>%
  mutate(Year = 2022)

# Select relevant columns, remove missing values, and keep distinct records
School_2022_2023 = School_2022_2023 %>%
  select(Year, PCODE, SCHNAME, ATT8SCR) %>%
  drop_na() %>%
  distinct()


combinedschool = rbind(School_2021_2022,School_2022_2023)
write.csv(combinedschool, "Cleaning\\Cleaned Data\\CombinedSchool.csv",row.names = FALSE)


pattern = ' .*$'

Cleanedcombinedschool = combinedschool %>% 
  mutate(ID = row_number()) %>% 
  mutate(shortPostcode=gsub(pattern,"",PCODE)) %>%
  filter (ATT8SCR != "NE" & ATT8SCR != "SUPP") %>% 
  filter(ATT8SCR !=""& shortPostcode!=""& PCODE!="") %>% 
  select( ID,Year,PCODE,shortPostcode,SCHNAME, ATT8SCR,) %>% 
  na.omit() %>% 
  distinct()
View(Cleanedcombinedschool)
colnames(Cleanedcombinedschool) = c("ID", "Year", "Postcode", "shortPostcode", "SchoolName", "Attainment8Score")

write.csv(Cleanedcombinedschool, "Cleaning\\Cleaned Data\\cleanedSchoolData.csv",row.names = FALSE)


Post=read.csv("Cleaning\\Cleaned Data\\Combined_House_Pricing_2019-2022.csv") %>% 
  select(Postcode,county) %>% 
  mutate(shortPostcode=gsub(pattern,"",Postcode)) %>% 
  select(county,shortPostcode)

# School data cleaning separately for OXFORDSHIRE and YORKSHIRE

OXFORDSHIRESchoolData = Cleanedcombinedschool %>% 
  left_join(Post,by = "shortPostcode") %>% 
  select(Year, Postcode, shortPostcode, SchoolName, Attainment8Score,county) %>% 
  filter(county=="OXFORDSHIRE") %>% 
  na.omit() %>% 
  distinct() %>% 
  mutate(ID = row_number()) %>% 
  select(ID,Year, Postcode, shortPostcode, SchoolName, Attainment8Score)

write.csv(OXFORDSHIRESchoolData, "Cleaning\\Cleaned Data\\OXFORDSHIRESchoolData.csv",row.names = FALSE) 

YORKSHIRESchoolData = Cleanedcombinedschool %>% 
  left_join(Post,by = "shortPostcode") %>% 
  select(Year, Postcode, shortPostcode, SchoolName, Attainment8Score,county) %>% 
  filter(county=="YORK" | county=="WEST YORKSHIRE" | county=="SOUTH YORKSHIRE" | county=="NORTH YORKSHIRE") %>% 
  na.omit() %>% 
  distinct() %>% 
  mutate(ID = row_number()) %>% 
  select(ID,Year, Postcode, shortPostcode, SchoolName, Attainment8Score)

View(YORKSHIRESchoolData)

write.csv(YORKSHIRESchoolData, "Cleaning\\Cleaned Data\\YORKSHIRESchoolData.csv",row.names = FALSE) 

#--------------
Town = read_csv("Cleaning\\Cleaned Data\\Cleaned_Town_population.csv")%>% 
  select(shortPostcode,District)


schoolData = read_csv("Cleaning\\Cleaned Data\\CombinedSchool.csv", show_col_types = FALSE)
colnames(schoolData)[colnames(schoolData) == "PCODE"] <- "shortPostcode"

view(Town)
view(schoolData)
view(YORKSHIRESchoolData)
view(group_by(OXFORDSHIRESchoolData,shortPostcode))

#to include information about the town associated with each school in the schoolData, the join would allow you to add columns from the Town data frame (such as town name, population, geographic details, etc.) to the schoolData data frame.schoolData = schoolData %>% 
schoolData = schoolData %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit()