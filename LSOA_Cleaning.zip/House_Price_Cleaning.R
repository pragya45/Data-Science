library(tidyverse)
library(dplyr)
library(stringi)
library(scales)

setwd("D:\\DATASCIENCE")

pp2019 = read_csv("D:\\DATASCIENCE\\Datasets\\housePricing\\housepricing-2019.csv", show_col_types = FALSE)
pp2020 = read_csv("D:\\DATASCIENCE\\Datasets\\housePricing\\housepricing-2020.csv", show_col_types = FALSE)
pp2021 = read_csv("D:\\DATASCIENCE\\Datasets\\housePricing\\housepricing-2021.csv",show_col_types = FALSE)
pp2022= read_csv("D:\\DATASCIENCE\\Datasets\\housePricing\\housepricing-2022.csv",show_col_types = FALSE)



colnames(pp2019) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County", "Type1", "Type2" )
colnames(pp2020) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County", "Type1", "Type2")
colnames(pp2021) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County" , "Type1", "Type2")
colnames(pp2022) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County" , "Type1", "Type2")

HousePrices = rbind(pp2019,pp2020,pp2021,pp2022) %>% 
  na.omit() %>% 
  distinct() %>% 
  as_tibble()
View(HousePrices)

write.csv(HousePrices, "D:\\DATASCIENCE\\Cleaning\\Cleaned Data\\Combined_House_Pricing_2019-2022.csv")



FilteredHousePrices = filter(HousePrices, County == 'OXFORDSHIRE' | County == 'YORK' | County == 'WEST YORKSHIRE' | County == 'NORTH YORKSHIRE' | County == 'SOUTH YORKSHIRE' )

# Replace "YORK" with "YORKSHIRE" in the COUNTY column
FilteredHousePrices$County[FilteredHousePrices$County == "YORK"] <- "YORKSHIRE"


view(FilteredHousePrices)

pattern = ' .*$'

FilteredHousePrices = FilteredHousePrices %>% 
  mutate(shortPostcode=gsub(pattern,"",PostCode)) %>%
  mutate(Year = str_trim(substring(Year, 1,4))) %>% 
  select(PostCode,shortPostcode,Year,PAON,Price) %>% 
  na.omit() %>% 
  distinct() %>% 
  as_tibble()
View(FilteredHousePrices)


# exporting filtered data set to  csv
write.csv(FilteredHousePrices, "D:\\DATASCIENCE\\Cleaning\\Cleaned DataCleaned_House_Pricing_2019-2022.csv",row.names = FALSE)

